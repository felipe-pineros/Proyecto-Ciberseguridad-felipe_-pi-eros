# Proyecto-Ciberseguridad (FULL)

Estructura con **BackEnd** (Express + TS + Mongo + JWT) y **FrontEnd** (React + TS + Vite + Bootstrap).

## Cómo iniciar

### 1) BackEnd
```bash
cd BackEnd
npm i
npm run dev
```

- Requiere MongoDB local en `mongodb://127.0.0.1:27017/cybersecapp` (puedes cambiarlo en `.env`).
- Healthcheck: `http://localhost:4000/api/health`

### 2) FrontEnd
```bash
cd FrontEnd
npm i
npm run dev
```
- Abre `http://localhost:5173`
- `.env` ya apunta a `VITE_API_URL=http://localhost:4000/api`

## Rutas útiles
- Front: `/login`, `/register`, `/incidents`
- API: `/api/auth/register`, `/api/auth/login`, `/api/incidents` (GET/POST/PUT/DELETE)

## Notas
- Concurrencia optimista: `PUT /api/incidents/:id` debe enviar header `If-Match` con la versión `__v`.
- Autenticación estática de prueba en Front: `admin@lab.com / Admin123*`.
