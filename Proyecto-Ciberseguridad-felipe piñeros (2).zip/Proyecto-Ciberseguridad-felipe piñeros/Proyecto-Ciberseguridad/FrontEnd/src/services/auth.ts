import { api } from './api'
export function login(body: { email: string; password: string }) {
  return api<{ token: string; user: { email: string; role?: string } }>('/auth/login', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}
export function register(body: { email: string; password: string }) {
  return api<{ token: string; user: { email: string; role?: string } }>('/auth/register', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}
