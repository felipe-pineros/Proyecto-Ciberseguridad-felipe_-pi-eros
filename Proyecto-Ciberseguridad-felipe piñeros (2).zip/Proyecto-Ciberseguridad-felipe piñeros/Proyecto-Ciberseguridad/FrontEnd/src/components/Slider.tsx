export default function Slider() {
  return (
    <div id="mainCarousel" className="carousel slide" data-bs-ride="carousel">
      <div className="carousel-inner">
        <div className="carousel-item active">
          <img className="d-block w-100" src="https://picsum.photos/1200/360?1" alt="Threat intel" />
          <div className="carousel-caption d-none d-md-block">
            <h5>Monitorea Incidentes</h5>
            <p>Registra, clasifica y da seguimiento a eventos de ciberseguridad.</p>
          </div>
        </div>
        <div className="carousel-item">
          <img className="d-block w-100" src="https://picsum.photos/1200/360?2" alt="SOC" />
          <div className="carousel-caption d-none d-md-block">
            <h5>Severidades y estados</h5>
            <p>LOW / MEDIUM / HIGH / CRITICAL y flujo OPEN → RESOLVED.</p>
          </div>
        </div>
      </div>
      <button className="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
      </button>
      <button className="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
        <span className="carousel-control-next-icon" aria-hidden="true"></span>
      </button>
    </div>
  )
}
