import { Link, NavLink } from 'react-router-dom'
import { useAuth } from '../context/useAuth'

export default function Navbar() {
  const { isAuth, user, logout } = useAuth()
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark border-bottom">
      <div className="container">
        <Link className="navbar-brand" to="/">CyberSec Lab</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div id="nav" className="collapse navbar-collapse">
          <ul className="navbar-nav me-auto">
            <li className="nav-item"><NavLink className="nav-link" to="/">Inicio</NavLink></li>
            <li className="nav-item"><NavLink className="nav-link" to="/incidents">Incidentes</NavLink></li>
          </ul>
          <ul className="navbar-nav">
            {!isAuth ? (
              <>
                <li className="nav-item"><NavLink className="nav-link" to="/login">Iniciar sesión</NavLink></li>
                <li className="nav-item"><NavLink className="nav-link" to="/register">Registrarse</NavLink></li>
              </>
            ) : (
              <>
                <li className="nav-item"><span className="nav-link">👤 {user?.email}</span></li>
                <li className="nav-item"><button className="btn btn-outline-light btn-sm" onClick={logout}>Salir</button></li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  )
}
