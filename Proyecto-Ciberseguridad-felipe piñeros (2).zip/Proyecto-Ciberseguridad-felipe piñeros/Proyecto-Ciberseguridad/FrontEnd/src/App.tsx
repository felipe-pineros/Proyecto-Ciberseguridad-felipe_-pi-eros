import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import Incidents from './pages/Incidents'
import NotFound from './pages/NotFound'
import Protected from './components/Protected'

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/login" element={<Login/>} />
        <Route path="/register" element={<Register/>} />
        <Route path="/incidents" element={<Protected><Incidents/></Protected>} />
        <Route path="*" element={<NotFound/>} />
      </Routes>
      <Footer />
    </>
  )
}
