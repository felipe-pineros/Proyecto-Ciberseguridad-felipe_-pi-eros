export default function NotFound() {
  return <div className="container my-5"><h2>404</h2><p>Página no encontrada</p></div>
}
