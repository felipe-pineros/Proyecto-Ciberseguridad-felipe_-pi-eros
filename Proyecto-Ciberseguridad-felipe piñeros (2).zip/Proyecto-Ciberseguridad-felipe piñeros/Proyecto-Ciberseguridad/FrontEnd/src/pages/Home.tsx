import Slider from '../components/Slider'

export default function Home() {
  return (
    <>
      <header className="header-hero">
        <div className="container">
          <h1 className="display-5 fw-bold">CyberSec Lab — Línea de Profundización</h1>
          <p className="lead">Proyecto: gestión de incidentes, autenticación, CRUD, excepciones y concurrencia.</p>
        </div>
      </header>
      <div className="container my-4">
        <Slider />
        <div className="row g-3 mt-3">
          <div className="col-md-4">
            <div className="card card-incident p-3">
              <h5>Autenticación</h5>
              <p>Login estático y dinámico con JWT y contraseñas cifradas.</p>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card card-incident p-3">
              <h5>Incidentes</h5>
              <p>Registra, edita, elimina y lista incidentes (GET/POST/PUT/DELETE).</p>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card card-incident p-3">
              <h5>Concurrencia</h5>
              <p>Actualización con <em>If-Match</em> y versión (__v) — conflicto 409 si hay desfasaje.</p>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
