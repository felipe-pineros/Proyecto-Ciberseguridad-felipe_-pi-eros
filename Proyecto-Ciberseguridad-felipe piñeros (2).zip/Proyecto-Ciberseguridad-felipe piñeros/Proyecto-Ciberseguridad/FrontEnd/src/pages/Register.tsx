import { useState } from 'react'
import { useAuth } from '../context/useAuth'

export default function Register() {
  const { register } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [msg, setMsg] = useState<string>()

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    try {
      setMsg(undefined)
      await register(email, password)
      setMsg('✅ Registro exitoso e inicio de sesión.')
    } catch (err: any) {
      setMsg('❌ ' + (err?.message || 'Error'))
    }
  }

  return (
    <div className="container my-4" style={{maxWidth: 480}}>
      <h2 className="mb-3">Registro</h2>
      <form onSubmit={onSubmit} className="card card-incident p-3">
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input className="form-control" value={email} onChange={e=>setEmail(e.target.value)} type="email" required/>
        </div>
        <div className="mb-3">
          <label className="form-label">Contraseña</label>
          <input className="form-control" value={password} onChange={e=>setPassword(e.target.value)} type="password" required/>
        </div>
        <button className="btn btn-primary w-100">Crear cuenta</button>
        {msg && <p className="mt-3">{msg}</p>}
      </form>
    </div>
  )
}
