import { useState } from 'react'
import { useAuth } from '../context/useAuth'

export default function Login() {
  const { loginDynamic, loginStatic } = useAuth()
  const [mode, setMode] = useState<'dynamic'|'static'>('dynamic')
  const [email, setEmail] = useState('admin@lab.com')
  const [password, setPassword] = useState('Admin123*')
  const [msg, setMsg] = useState<string>()

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    try {
      setMsg(undefined)
      if (mode === 'dynamic') await loginDynamic(email, password)
      else await loginStatic(email, password)
      setMsg('✅ Inicio de sesión correcto.')
    } catch (err: any) {
      setMsg('❌ ' + (err?.message || 'Error'))
    }
  }

  return (
    <div className="container my-4" style={{maxWidth: 480}}>
      <h2 className="mb-3">Iniciar sesión</h2>
      <div className="btn-group mb-3">
        <button className={`btn btn-${mode==='dynamic'?'primary':'outline-primary'}`} onClick={()=>setMode('dynamic')}>Dinámico</button>
        <button className={`btn btn-${mode==='static'?'primary':'outline-primary'}`} onClick={()=>setMode('static')}>Estático</button>
      </div>
      <form onSubmit={onSubmit} className="card card-incident p-3">
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input className="form-control" value={email} onChange={e=>setEmail(e.target.value)} type="email" required/>
        </div>
        <div className="mb-3">
          <label className="form-label">Contraseña</label>
          <input className="form-control" value={password} onChange={e=>setPassword(e.target.value)} type="password" required/>
        </div>
        <button className="btn btn-primary w-100">Entrar</button>
        {msg && <p className="mt-3">{msg}</p>}
      </form>
    </div>
  )
}
