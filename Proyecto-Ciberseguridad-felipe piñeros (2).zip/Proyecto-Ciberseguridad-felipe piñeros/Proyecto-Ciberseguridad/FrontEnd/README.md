# CyberSec FrontEnd (React + TS + Vite + Bootstrap)

## Requisitos
- Node 18+
- BackEnd corriendo en http://localhost:4000

## Variables de entorno
Crea `.env` (ya incluido) con:
```
VITE_API_URL=http://localhost:4000/api
```

## Instalar y arrancar
```bash
npm i
npm run dev
```

## Rutas
- `/` Home (header + slider + tarjetas)
- `/login` Login (modo dinámico contra API o estático admin@lab.com / Admin123*)
- `/register` Registro (contra API)
- `/incidents` CRUD protegido (GET/POST/PUT/DELETE). Requiere login. Concurrencia vía `If-Match` y `__v`.
