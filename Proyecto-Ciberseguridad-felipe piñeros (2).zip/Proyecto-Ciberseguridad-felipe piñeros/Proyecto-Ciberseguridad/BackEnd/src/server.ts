import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { config } from './config';
import { connectDB } from './db';
import authRoutes from './routes/auth.routes';
import incidentsRoutes from './routes/incidents.routes';
import { errorHandler } from './middlewares/errorHandler';

async function bootstrap() {
  await connectDB();
  const app = express();

  app.use(cors({ origin: config.corsOrigin, credentials: true }));
  app.use(helmet());
  app.use(express.json());
  app.use(morgan('dev'));

  const limiter = rateLimit({ windowMs: 60_000, max: 100 });
  app.use(limiter);

  app.get('/api/health', (_req, res) => res.json({ ok: true, at: new Date().toISOString() }));
  app.use('/api/auth', authRoutes);
  app.use('/api/incidents', incidentsRoutes);

  app.use(errorHandler);

  app.listen(config.port, () => {
    console.log(`🚀 API escuchando en http://localhost:${config.port}`);
  });
}

bootstrap();
