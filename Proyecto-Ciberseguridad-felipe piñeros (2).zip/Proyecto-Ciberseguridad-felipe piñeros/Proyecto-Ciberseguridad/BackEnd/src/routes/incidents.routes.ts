import { Router } from 'express';
import { Incident } from '../models/Incident';
import { auth } from '../middlewares/auth';

const router = Router();

router.get('/', auth, async (_req, res, next) => {
  try {
    const docs = await Incident.find().sort({ createdAt: -1 });
    res.json(docs);
  } catch (e) { next(e); }
});

router.post('/', auth, async (req, res, next) => {
  try {
    const { title, description, severity } = req.body;
    const reportedBy = (req as any).user.uid;
    const doc = await Incident.create({ title, description, severity, reportedBy });
    res.status(201).json(doc);
  } catch (e) { next(e); }
});

router.put('/:id', auth, async (req, res, next) => {
  try {
    const id = req.params.id;
    const clientVersion = Number(req.headers['if-match']);
    if (Number.isNaN(clientVersion)) return res.status(428).json({ error: 'Falta encabezado If-Match' });

    const doc = await Incident.findById(id);
    if (!doc) return res.status(404).json({ error: 'No encontrado' });

    (doc as any).__v = clientVersion;
    const { title, description, severity, status } = req.body;
    if (title) doc.title = title;
    if (description) doc.description = description;
    if (severity) doc.severity = severity;
    if (status) doc.status = status;

    const saved = await doc.save();
    res.json(saved);
  } catch (e) { next(e); }
});

router.delete('/:id', auth, async (req, res, next) => {
  try {
    const out = await Incident.findByIdAndDelete(req.params.id);
    if (!out) return res.status(404).json({ error: 'No encontrado' });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default router;
