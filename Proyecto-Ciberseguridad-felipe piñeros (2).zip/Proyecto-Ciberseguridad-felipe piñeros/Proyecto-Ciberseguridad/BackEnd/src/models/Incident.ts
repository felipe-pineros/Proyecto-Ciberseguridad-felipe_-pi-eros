import { Schema, model, Types } from 'mongoose';

const incidentSchema = new Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  severity: { type: String, enum: ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'], default: 'LOW' },
  status: { type: String, enum: ['OPEN', 'IN_PROGRESS', 'RESOLVED'], default: 'OPEN' },
  reportedBy: { type: Types.ObjectId, ref: 'User', required: true },
}, { timestamps: true, versionKey: '__v' });

incidentSchema.set('optimisticConcurrency', true);

export const Incident = model('Incident', incidentSchema);
