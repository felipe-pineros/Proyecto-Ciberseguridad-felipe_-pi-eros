import { useEffect, useState } from 'react'
import { createIncident, listIncidents, updateIncident, removeIncident, type Incident } from '../services/incidents'

export default function Incidents(){
  const [items, setItems] = useState<Incident[]>([])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [severity, setSeverity] = useState<'LOW'|'MEDIUM'|'HIGH'|'CRITICAL'>('LOW')
  const [msg, setMsg] = useState<string>()

  async function refresh(){ const data = await listIncidents(); setItems(data) }
  useEffect(()=>{ refresh() }, [])

  async function onCreate(e: React.FormEvent){
    e.preventDefault(); setMsg(undefined)
    try{
      await createIncident({ title, description, severity })
      setTitle(''); setDescription(''); setSeverity('LOW')
      await refresh(); setMsg('✅ Incidente creado')
    }catch(err:any){ setMsg('❌ ' + (err?.message || 'Error')) }
  }

  async function onResolve(it: Incident){
    try{ await updateIncident(it._id, { status: 'RESOLVED' }, it.__v); await refresh() }
    catch{ alert('Conflicto de versión (409). Refresca la lista e intenta de nuevo.') }
  }

  async function onDelete(id: string){
    if(!confirm('¿Eliminar incidente?')) return
    await removeIncident(id); await refresh()
  }

  return (
    <div className="container section">
      <div className="row g-3 align-items-end">
        <div className="col-lg-9">
          <h3 className="mb-0"><i className="bi-clipboard2-check me-2"></i>Registrar y gestionar incidentes</h3>
          <p className="text-faint mb-0">Registra eventos, cambia su estado y controla concurrencia (If-Match con versión).</p>
        </div>
      </div>

      <form onSubmit={onCreate} className="card card-glass p-3 my-3">
        <div className="row g-2">
          <div className="col-md-4">
            <label className="form-label">Título</label>
            <input className="form-control" value={title} onChange={e=>setTitle(e.target.value)} required/>
          </div>
          <div className="col-md-5">
            <label className="form-label">Descripción</label>
            <input className="form-control" value={description} onChange={e=>setDescription(e.target.value)} required/>
          </div>
          <div className="col-md-2">
            <label className="form-label">Severidad</label>
            <select className="form-select" value={severity} onChange={e=>setSeverity(e.target.value as any)}>
              <option>LOW</option><option>MEDIUM</option><option>HIGH</option><option>CRITICAL</option>
            </select>
          </div>
          <div className="col-md-1 d-grid">
            <label className="form-label">&nbsp;</label>
            <button className="btn btn-primary">Añadir</button>
          </div>
        </div>
        {msg && <p className="mt-3">{msg}</p>}
      </form>

      <div className="row g-3">
        {items.map(it => (
          <div key={it._id} className="col-md-6">
            <div className="card card-glass p-3 h-100">
              <div className="d-flex justify-content-between align-items-start">
                <div>
                  <h5 className="mb-1">{it.title}</h5>
                  <p className="mb-2 text-faint">{it.description}</p>
                </div>
                <span className="badge bg-info">{it.severity}</span>
              </div>
              <div className="d-flex justify-content-between align-items-center mt-auto">
                <span className={`badge ${it.status==='RESOLVED'?'bg-success':'bg-warning text-dark'}`}>{it.status}</span>
                <div className="btn-group">
                  {it.status!=='RESOLVED' && (
                    <button className="btn btn-sm btn-outline-light" onClick={()=>onResolve(it)}><i className="bi-check2-circle me-1"></i>Resolver</button>
                  )}
                  <button className="btn btn-sm btn-outline-danger" onClick={()=>onDelete(it._id)}><i className="bi-trash me-1"></i>Eliminar</button>
                </div>
              </div>
              <small className="text-secondary">v{it.__v}</small>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
