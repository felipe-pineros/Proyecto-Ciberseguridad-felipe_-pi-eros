import { useEffect, useState } from 'react'
import { useAuth } from '../context/useAuth'
import { sha256 } from '../utils/crypto'

export default function Login(){
  const { loginDynamic, loginStatic } = useAuth()
  const [mode, setMode] = useState<'dynamic'|'static'>('dynamic')
  const [email, setEmail] = useState('admin@lab.com')
  const [password, setPassword] = useState('Admin123*')
  const [showPwd, setShowPwd] = useState(false)
  const [encrypt, setEncrypt] = useState(false)
  const [msg, setMsg] = useState<string>()
  const [hashPreview, setHashPreview] = useState<string>('')

  useEffect(()=>{
    let ignore = false;
    async function run(){
      if(encrypt) {
        const h = await sha256(password);
        if(!ignore) setHashPreview(h);
      } else setHashPreview('');
    }
    run(); return ()=>{ ignore = true };
  }, [encrypt, password])

  async function onSubmit(e: React.FormEvent){
    e.preventDefault()
    try {
      setMsg(undefined)
      if (mode === 'dynamic') await loginDynamic(email, password)
      else await loginStatic(email, password)
      setMsg('✅ Inicio de sesión correcto.')
    } catch (err: any) {
      setMsg('❌ ' + (err?.message || 'Error'))
    }
  }

  return (
    <div className="container section">
      <div className="row justify-content-center g-0">
        <div className="col-xl-8">
          <div className="card card-glass overflow-hidden">
            <div className="row g-0">
              <div className="col-md-6 d-none d-md-block" style={{background:`center/cover no-repeat url('https://images.unsplash.com/photo-1535223289827-42f1e9919769?q=80&w=1200&fit=crop')`}}></div>
              <div className="col-md-6 p-4">
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <h4 className="mb-0"><i className="bi-door-open me-2"></i>Iniciar sesión</h4>
                  <div className="btn-group btn-group-sm">
                    <button className={`btn btn-${mode==='dynamic'?'primary':'outline-primary'}`} onClick={()=>setMode('dynamic')}>Dinámico</button>
                    <button className={`btn btn-${mode==='static'?'primary':'outline-primary'}`} onClick={()=>setMode('static')}>Estático</button>
                  </div>
                </div>

                <form onSubmit={onSubmit}>
                  <div className="form-floating mb-3">
                    <input className="form-control" id="email" value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="email@dominio.com" required />
                    <label htmlFor="email">Email</label>
                  </div>

                  <div className="form-floating mb-3 position-relative">
                    <input className="form-control" id="pwd" value={password} onChange={e=>setPassword(e.target.value)} type={showPwd?'text':'password'} placeholder="••••••••" required />
                    <label htmlFor="pwd">Contraseña</label>
                    <button type="button" className="btn btn-sm btn-soft position-absolute end-0 top-0 mt-2 me-2" onClick={()=>setShowPwd(s=>!s)} aria-label="Mostrar contraseña">
                      <i className={`bi-${showPwd?'eye-slash':'eye'}`}></i>
                    </button>
                  </div>

                  <div className="form-check mb-2">
                    <input className="form-check-input" type="checkbox" id="encrypt" checked={encrypt} onChange={e=>setEncrypt(e.target.checked)} />
                    <label className="form-check-label" htmlFor="encrypt">Cifrar en cliente (demo SHA-256)</label>
                  </div>
                  {encrypt && <small className="text-faint d-block mb-3">SHA-256: <code className="text-wrap">{hashPreview}</code></small>}

                  <button className="btn btn-primary w-100">Entrar</button>
                  {msg && <p className="mt-3">{msg}</p>}
                </form>
                <p className="text-faint small mt-3">Tip (estático): <code>admin@lab.com</code> / <code>Admin123*</code></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
