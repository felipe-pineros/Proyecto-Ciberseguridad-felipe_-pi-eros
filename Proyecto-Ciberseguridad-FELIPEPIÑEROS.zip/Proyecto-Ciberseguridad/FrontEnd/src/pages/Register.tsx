import { useState } from 'react'
import { useAuth } from '../context/useAuth'

export default function Register(){
  const { register } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [msg, setMsg] = useState<string>()

  async function onSubmit(e: React.FormEvent){
    e.preventDefault()
    try {
      setMsg(undefined)
      await register(email, password)
      setMsg('✅ Registro exitoso e inicio de sesión.')
    } catch (err: any) {
      setMsg('❌ ' + (err?.message || 'Error'))
    }
  }

  return (
    <div className="container section">
      <div className="row justify-content-center g-0">
        <div className="col-xl-7">
          <div className="card card-glass overflow-hidden">
            <div className="row g-0">
              <div className="col-md-6 d-none d-md-block" style={{background:`center/cover no-repeat url('https://images.unsplash.com/photo-1544198365-3c4b3d8a20fa?q=80&w=1200&fit=crop')`}}></div>
              <div className="col-md-6 p-4">
                <h4 className="mb-3"><i className="bi-person-plus me-2"></i>Crear cuenta</h4>
                <form onSubmit={onSubmit}>
                  <div className="form-floating mb-3">
                    <input className="form-control" id="email" type="email" placeholder="email@dominio.com" value={email} onChange={e=>setEmail(e.target.value)} required />
                    <label htmlFor="email">Email</label>
                  </div>
                  <div className="form-floating mb-3">
                    <input className="form-control" id="pwd" type="password" placeholder="••••••••" value={password} onChange={e=>setPassword(e.target.value)} required />
                    <label htmlFor="pwd">Contraseña</label>
                  </div>
                  <button className="btn btn-primary w-100">Registrarse</button>
                  {msg && <p className="mt-3">{msg}</p>}
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
