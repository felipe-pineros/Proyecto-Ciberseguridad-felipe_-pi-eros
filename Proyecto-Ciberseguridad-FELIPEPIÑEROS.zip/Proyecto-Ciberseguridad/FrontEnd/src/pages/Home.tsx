import Slider from '../components/Slider'
import { Link } from 'react-router-dom'

export default function Home(){
  return (<>
    {/* HERO */}
    <header className="header-hero text-center py-5">
      <div className="container">
        <h1 className="display-5 fw-bold">Bienvenido a <span className="text-primary">CiberSeguridad Pro</span></h1>
        <p className="lead max-720 mx-auto">Protege tu mundo digital con herramientas y recursos de ciberseguridad. Aprende a mantener tus datos seguros, proteger tu identidad en línea y fortalecer tus sistemas contra amenazas.</p>
        <div className="d-flex justify-content-center gap-2">
          <Link className="btn btn-primary" to="/incidents"><i className="bi-shield-check me-1"></i> Ir al Laboratorio</Link>
          <Link className="btn btn-soft" to="/login"><i className="bi-box-arrow-in-right me-1"></i> Iniciar sesión</Link>
        </div>
      </div>
      <div className="wave"><svg viewBox="0 0 1440 60" preserveAspectRatio="none"><path fill="rgba(255,255,255,.06)" d="M0,0 C200,60 400,0 600,40 C800,80 1000,20 1200,40 C1300,50 1400,40 1440,30 L1440,60 L0,60 Z"></path></svg></div>
    </header>

    {/* SLIDER */}
    <div className="container section">
      <Slider />
    </div>

    {/* FEATURES */}
    <section className="section">
      <div className="container">
        <h2 className="h3 mb-3"><i className="bi-stars me-2"></i>Lo que aprenderás</h2>
        <div className="row g-4">
          <div className="col-md-4"><div className="card card-glass h-100 p-3">
            <h5 className="mb-2"><i className="bi-lock-fill me-2"></i>Autenticación segura</h5>
            <p className="text-faint">Login estático/dinámico, JWT, hash de contraseñas, y demo de cifrado (SHA-256) en cliente.</p>
            <ul className="small text-faint mb-0"><li>Buenas prácticas de contraseñas</li><li>MFA y rotación de claves</li></ul>
          </div></div>
          <div className="col-md-4"><div className="card card-glass h-100 p-3">
            <h5 className="mb-2"><i className="bi-bug-fill me-2"></i>Gestión de incidentes</h5>
            <p className="text-faint">CRUD completo (crear, listar, resolver, eliminar) con control de versión y manejo de concurrencia.</p>
            <ul className="small text-faint mb-0"><li>Severidades y estados</li><li>Conflictos 409 con <code>If-Match</code></li></ul>
          </div></div>
          <div className="col-md-4"><div className="card card-glass h-100 p-3">
            <h5 className="mb-2"><i className="bi-hdd-network me-2"></i>Hardening & Red</h5>
            <p className="text-faint">Segmentación de red, firewalls, principio de mínimo privilegio y actualizaciones constantes.</p>
            <ul className="small text-faint mb-0"><li>Modelos de amenaza</li><li>Buenas prácticas de despliegue</li></ul>
          </div></div>
        </div>
      </div>
    </section>

    {/* GALLERY */}
    <section className="section">
      <div className="container">
        <h2 className="h3 mb-3"><i className="bi-images me-2"></i>Galería</h2>
        <div className="row g-3">
          {[
            'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?q=80&w=1200&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?q=80&w=1200&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1518779578993-ec3579fee39f?q=80&w=1200&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1510511233900-1982d92bd835?q=80&w=1200&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1556157382-97eda2d62296?q=80&w=1200&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?q=80&w=1200&auto=format&fit=crop'
          ].map((src, i)=>(
            <div key={i} className="col-6 col-md-4">
              <div className="ratio ratio-16x9 rounded-4 overflow-hidden shadow-sm gallery-item">
                <img src={src} className="w-100 h-100 object-fit-cover" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* PASOS */}
    <section className="section">
      <div className="container">
        <h2 className="h3 mb-3"><i className="bi-list-ol me-2"></i>Cómo trabajamos</h2>
        <div className="row g-4">
          <div className="col-md-4"><div className="card card-glass h-100 p-3"><h6 className="text-primary">1. Identificación</h6><p className="text-faint mb-0">Recolección de evidencias, clasificación del incidente y evaluación del impacto.</p></div></div>
          <div className="col-md-4"><div className="card card-glass h-100 p-3"><h6 className="text-primary">2. Contención</h6><p className="text-faint mb-0">Aislamiento de equipos y mitigación para evitar propagación.</p></div></div>
          <div className="col-md-4"><div className="card card-glass h-100 p-3"><h6 className="text-primary">3. Erradicación & Recuperación</h6><p className="text-faint mb-0">Eliminación del origen, restauración segura y lecciones aprendidas.</p></div></div>
        </div>
      </div>
    </section>

    {/* FAQ */}
    <section className="section">
      <div className="container">
        <h2 className="h3 mb-3"><i className="bi-question-circle me-2"></i>Preguntas frecuentes</h2>
        <div className="accordion" id="faq">
          <div className="accordion-item card-glass">
            <h2 className="accordion-header">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#f1">
                ¿Puedo usar el login si no tengo el BackEnd?
              </button>
            </h2>
            <div id="f1" className="accordion-collapse collapse" data-bs-parent="#faq">
              <div className="accordion-body text-faint">
                Sí. Usa el modo <strong>Estático</strong> en /login con las credenciales demo.
                Para modo <strong>Dinámico</strong> debes levantar el BackEnd (Express/Mongo/JWT).
              </div>
            </div>
          </div>
          <div className="accordion-item card-glass mt-2">
            <h2 className="accordion-header">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#f2">
                ¿Dónde quedan mis incidentes?
              </button>
            </h2>
            <div id="f2" className="accordion-collapse collapse" data-bs-parent="#faq">
              <div className="accordion-body text-faint">
                Se guardan en la base de datos del BackEnd. Si solo quieres probar la UI, puedes
                simular con datos y luego conectarlo a tu API real.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </>)
}
