import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import * as authApi from '../services/auth'

type User = { email: string; role?: string } | null

type Ctx = {
  user: User
  isAuth: boolean
  loginDynamic: (email: string, password: string) => Promise<void>
  loginStatic: (email: string, password: string) => Promise<void>
  register: (email: string, password: string) => Promise<void>
  logout: () => void
}

const Ctx = createContext<Ctx>(null as any)

export function AuthProvider({ children }: { children: ReactNode }){
  const [user, setUser] = useState<User>(null)

  useEffect(() => {
    const saved = localStorage.getItem('auth')
    if (saved) setUser(JSON.parse(saved))
  }, [])

  function save(u: User, token?: string) {
    setUser(u)
    localStorage.setItem('auth', JSON.stringify(u))
    if (token) localStorage.setItem('token', token)
  }

  function logout() {
    setUser(null)
    localStorage.removeItem('auth')
    localStorage.removeItem('token')
  }

  async function loginDynamic(email: string, password: string) {
    const { token, user } = await authApi.login({ email, password })
    save(user, token)
  }

  async function loginStatic(email: string, password: string) {
    if (email === 'admin@lab.com' && password === 'Admin123*') {
      save({ email, role: 'admin' })
      return
    }
    throw new Error('Credenciales estáticas inválidas (usa admin@lab.com / Admin123*)')
  }

  async function register(email: string, password: string) {
    const { token, user } = await authApi.register({ email, password })
    save(user, token)
  }

  return <Ctx.Provider value={{ user, isAuth: !!user, loginDynamic, loginStatic, register, logout }}>{children}</Ctx.Provider>
}

export const useAuth = () => useContext(Ctx)
