export default function Footer(){
  return (
    <footer className="footer-mini py-4 mt-5">
      <div className="container small d-flex justify-content-between">
        <span>© {new Date().getFullYear()} CiberSeguridad Pro</span>
        <span className="text-faint">Hardening • Detección • Respuesta</span>
      </div>
    </footer>
  )
}
