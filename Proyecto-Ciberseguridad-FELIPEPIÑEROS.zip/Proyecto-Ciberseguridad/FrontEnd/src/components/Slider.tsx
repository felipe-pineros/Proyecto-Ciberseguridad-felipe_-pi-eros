export default function Slider(){
  return (
    <div id="heroCarousel" className="carousel slide mb-4 rounded-4 overflow-hidden shadow" data-bs-ride="carousel">
      <div className="carousel-inner">
        <div className="carousel-item active">
          <img className="d-block w-100" src="https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=1600&auto=format&fit=crop" />
          <div className="carousel-caption d-none d-md-block">
            <h5 className="mb-1">Blue Team</h5>
            <p className="mb-0">Monitoreo, detección y respuesta ante incidentes.</p>
          </div>
        </div>
        <div className="carousel-item">
          <img className="d-block w-100" src="https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?q=80&w=1600&auto=format&fit=crop" />
          <div className="carousel-caption d-none d-md-block">
            <h5 className="mb-1">Autenticación</h5>
            <p className="mb-0">JWT, hash de contraseñas y MFA.</p>
          </div>
        </div>
        <div className="carousel-item">
          <img className="d-block w-100" src="https://images.unsplash.com/photo-1510511233900-1982d92bd835?q=80&w=1600&auto=format&fit=crop" />
          <div className="carousel-caption d-none d-md-block">
            <h5 className="mb-1">Hardening</h5>
            <p className="mb-0">Principio de mínimo privilegio y segmentación de red.</p>
          </div>
        </div>
      </div>
      <button className="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
      </button>
      <button className="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
        <span className="carousel-control-next-icon" aria-hidden="true"></span>
      </button>
    </div>
  )
}
