import { Link, NavLink } from 'react-router-dom'
import { useAuth } from '../context/useAuth'

export default function Navbar(){
  const { isAuth, user, logout } = useAuth()
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark bg-opacity-75 border-bottom sticky-top">
      <div className="container">
        <Link className="navbar-brand fw-semibold" to="/"><i className="bi-shield-lock me-2"></i>CiberSeguridad Pro</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div id="mainNav" className="collapse navbar-collapse">
          <ul className="navbar-nav me-auto">
            <li className="nav-item"><NavLink end className="nav-link" to="/">Inicio</NavLink></li>
            <li className="nav-item"><NavLink className="nav-link" to="/incidents">Incidentes</NavLink></li>
          </ul>
          <div className="d-flex align-items-center gap-2">
            <button className="btn btn-sm btn-soft" onClick={()=> (window as any).themeToggle?.()} title="Cambiar tema"><i className="bi-sun"></i></button>
            {!isAuth ? (
              <>
                <NavLink className="btn btn-outline-light btn-sm" to="/login">Iniciar sesión</NavLink>
                <NavLink className="btn btn-primary btn-sm" to="/register">Registro</NavLink>
              </>
            ) : (
              <div className="btn-group">
                <button className="btn btn-outline-light btn-sm" disabled>👤 {user?.email}</button>
                <button className="btn btn-danger btn-sm" onClick={logout}><i className="bi-box-arrow-right me-1"></i>Salir</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}
