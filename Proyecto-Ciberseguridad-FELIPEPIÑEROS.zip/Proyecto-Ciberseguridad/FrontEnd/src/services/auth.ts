import { api } from './api'
export const login = (body: { email: string; password: string }) =>
  api<{ token: string; user: { email: string; role?: string } }>('/auth/login', { method: 'POST', body: JSON.stringify(body) })
export const register = (body: { email: string; password: string }) =>
  api<{ token: string; user: { email: string; role?: string } }>('/auth/register', { method: 'POST', body: JSON.stringify(body) })
