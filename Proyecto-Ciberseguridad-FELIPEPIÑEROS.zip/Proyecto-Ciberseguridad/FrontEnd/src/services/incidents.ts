import { api } from './api'

export type Incident = {
  _id: string
  title: string
  description: string
  severity: 'LOW'|'MEDIUM'|'HIGH'|'CRITICAL'
  status: 'OPEN'|'IN_PROGRESS'|'RESOLVED'
  __v: number
}

export const listIncidents = () => api<Incident[]>('/incidents')
export const createIncident = (body: Partial<Incident>) =>
  api<Incident>('/incidents', { method: 'POST', body: JSON.stringify(body) })
export const updateIncident = (id: string, body: Partial<Incident>, version: number) =>
  api<Incident>(`/incidents/${id}`, { method: 'PUT', headers: { 'If-Match': String(version) }, body: JSON.stringify(body) })
export const removeIncident = (id: string) =>
  api<{ok:true}>(`/incidents/${id}`, { method: 'DELETE' })
