import type { ErrorRequestHandler } from 'express';

export const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
  console.error('❌ Error:', err);

  if ((err as any)?.name === 'VersionError') {
    return res.status(409).json({ error: 'Conflicto de versión. Refresca y reintenta.' });
  }
  if ((err as any)?.name === 'ValidationError') {
    return res.status(400).json({ error: (err as any).message });
  }
  res.status(500).json({ error: 'Error interno' });
};
