import { Router } from 'express';
import { Incident } from '../models/Incident';
import { auth } from '../middlewares/auth';

const router = Router();

router.get('/', auth, async (_req, res, next) => {
  try {
    const docs = await Incident.find().sort({ createdAt: -1 });
    res.json(docs);
  } catch (e) { next(e); }
});

router.post('/', auth, async (req, res, next) => {
  try {
    const { title, description, severity } = req.body;
    const reportedBy = (req as any).user.uid;
    const doc = await Incident.create({ title, description, severity, reportedBy });
    res.status(201).json(doc);
  } catch (e) { next(e); }
});

router.put('/:id', auth, async (req, res, next) => {
  try {
    const ifMatch = req.header('If-Match');
    const { id } = req.params;
    const update = req.body;

    if (ifMatch) {
      const current = await Incident.findById(id).select('__v');
      if (!current) return res.status(404).json({ error: 'No existe' });
      if (String(current.__v) !== String(ifMatch)) return res.status(409).json({ error: 'Conflicto de versión' });
    }

    const doc = await Incident.findByIdAndUpdate(id, { $set: update, $inc: { __v: 1 } }, { new: true });
    res.json(doc);
  } catch (e) { next(e); }
});

router.delete('/:id', auth, async (req, res, next) => {
  try {
    const { id } = req.params;
    await Incident.findByIdAndDelete(id);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default router;
