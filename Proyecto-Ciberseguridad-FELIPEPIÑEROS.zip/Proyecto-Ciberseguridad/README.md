# Proyecto CiberSeguridad Pro — FULL UX

## BackEnd
```
cd Proyecto-Ciberseguridad/BackEnd
npm i
npm run dev
# Health: http://localhost:4000/api/health
```
> Asegúrate de tener MongoDB ejecutándose (URI por defecto en `.env`).

## FrontEnd
```
cd Proyecto-Ciberseguridad/FrontEnd
npm i
npm run dev
# Abre: http://localhost:5173
```
Rutas: `/` (landing con slider/galería/faq) · `/login` (estático/dinámico + SHA-256) · `/register` · `/incidents` (CRUD protegido).
